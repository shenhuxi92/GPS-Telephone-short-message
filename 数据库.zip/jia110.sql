-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2021-02-07 11:57:16
-- 服务器版本： 5.6.50-log
-- PHP 版本： 7.0.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `jia110`
--

-- --------------------------------------------------------

--
-- 表的结构 `app_admin`
--

CREATE TABLE `app_admin` (
  `id` int(11) NOT NULL,
  `nickname` varchar(20) DEFAULT NULL COMMENT '昵称',
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `thumb` int(11) NOT NULL DEFAULT '1' COMMENT '管理员头像',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) NOT NULL COMMENT '修改时间',
  `login_time` int(11) DEFAULT NULL COMMENT '最后登录时间',
  `login_ip` varchar(100) DEFAULT NULL COMMENT '最后登录ip',
  `admin_cate_id` int(2) NOT NULL DEFAULT '1' COMMENT '管理员分组'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_admin`
--

INSERT INTO `app_admin` (`id`, `nickname`, `name`, `password`, `thumb`, `create_time`, `update_time`, `login_time`, `login_ip`, `admin_cate_id`) VALUES
(1, '百度先生', 'admin', 'cad5af023a17ae6383469f996e2a40ea', 9, 1510885948, 1611900759, 1612668984, '121.29.149.221', 1),
(116, '靓仔', 'jia110', '5a7055f7a337bfd84b2c82a4363a3d52', 10, 1611914939, 1611926402, 1612668704, '113.65.204.101', 1);

-- --------------------------------------------------------

--
-- 表的结构 `app_admin_cate`
--

CREATE TABLE `app_admin_cate` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `permissions` text COMMENT '权限菜单',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `desc` text COMMENT '备注'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_admin_cate`
--

INSERT INTO `app_admin_cate` (`id`, `name`, `permissions`, `create_time`, `update_time`, `desc`) VALUES
(1, '超级管理员', '1,2,3,4,5,51,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,49,50,52,53,54,59,67,68,70,55,56,57,62,65,66,63,64', 0, 1611915173, '超级管理员，拥有最高权限！');

-- --------------------------------------------------------

--
-- 表的结构 `app_admin_log`
--

CREATE TABLE `app_admin_log` (
  `id` int(11) NOT NULL,
  `admin_menu_id` int(11) NOT NULL COMMENT '操作菜单id',
  `admin_id` int(11) NOT NULL COMMENT '操作者id',
  `ip` varchar(100) DEFAULT NULL COMMENT '操作ip',
  `operation_id` varchar(200) DEFAULT NULL COMMENT '操作关联id',
  `create_time` int(11) NOT NULL COMMENT '操作时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_admin_log`
--

INSERT INTO `app_admin_log` (`id`, `admin_menu_id`, `admin_id`, `ip`, `operation_id`, `create_time`) VALUES
(1328, 49, 1, '106.57.47.196', '4', 1594577236),
(1329, 25, 1, '106.57.47.196', '86', 1594577270),
(1330, 50, 86, '106.57.47.196', '', 1594577297),
(1331, 50, 1, '106.57.47.196', '', 1594577424),
(1332, 50, 1, '171.9.48.110', '', 1594577891),
(1333, 54, 1, '171.9.48.110', '1318', 1594577917),
(1334, 54, 1, '171.9.48.110', '1317', 1594577930),
(1335, 54, 1, '171.9.48.110', '1319', 1594578029),
(1336, 54, 1, '171.9.48.110', '1320', 1594578099),
(1337, 50, 1, '171.9.48.110', '', 1594578560),
(1338, 50, 1, '171.9.48.110', '', 1594579403),
(1339, 50, 1, '106.57.47.196', '', 1594580037),
(1340, 50, 1, '171.9.48.110', '', 1594622772),
(1341, 50, 1, '171.9.48.110', '', 1594623217),
(1342, 54, 1, '171.9.48.110', '1321', 1594623783),
(1343, 50, 1, '106.57.33.160', '', 1594636420),
(1344, 25, 1, '106.57.33.160', '87', 1594636471),
(1345, 25, 1, '106.57.33.160', '88', 1594636489),
(1346, 25, 1, '106.57.33.160', '89', 1594636515),
(1347, 25, 1, '106.57.33.160', '90', 1594636538),
(1348, 25, 1, '106.57.33.160', '91', 1594636557),
(1349, 25, 1, '106.57.33.160', '92', 1594636573),
(1350, 25, 1, '106.57.33.160', '93', 1594636590),
(1351, 25, 1, '106.57.33.160', '94', 1594636610),
(1352, 25, 1, '106.57.33.160', '95', 1594636634),
(1353, 25, 1, '106.57.33.160', '96', 1594636663),
(1354, 25, 1, '106.57.33.160', '97', 1594636678),
(1355, 25, 1, '106.57.33.160', '98', 1594636692),
(1356, 25, 1, '106.57.33.160', '99', 1594636706),
(1357, 25, 1, '106.57.33.160', '100', 1594636723),
(1358, 25, 1, '106.57.33.160', '101', 1594636739),
(1359, 25, 1, '106.57.33.160', '102', 1594636753),
(1360, 25, 1, '106.57.33.160', '103', 1594636768),
(1361, 25, 1, '106.57.33.160', '104', 1594636788),
(1362, 25, 1, '106.57.33.160', '105', 1594636804),
(1363, 25, 1, '106.57.33.160', '106', 1594636820),
(1364, 25, 1, '106.57.33.160', '107', 1594636835),
(1365, 25, 1, '106.57.33.160', '108', 1594636854),
(1366, 25, 1, '106.57.33.160', '109', 1594636882),
(1367, 25, 1, '106.57.33.160', '110', 1594636900),
(1368, 25, 1, '106.57.33.160', '111', 1594636916),
(1369, 25, 1, '106.57.33.160', '112', 1594636932),
(1370, 25, 1, '106.57.33.160', '113', 1594636953),
(1371, 25, 1, '106.57.33.160', '114', 1594636971),
(1372, 25, 1, '106.57.33.160', '115', 1594636990),
(1373, 50, 86, '106.57.33.160', '', 1594637107),
(1374, 50, 1, '106.57.33.160', '', 1594637197),
(1375, 28, 1, '106.57.33.160', '21', 1594637296),
(1376, 50, 91, '106.57.33.160', '', 1594637474),
(1377, 50, 95, '106.57.118.241', '', 1594637477),
(1378, 50, 89, '106.57.33.160', '', 1594637508),
(1379, 50, 87, '106.57.118.241', '', 1594637626),
(1380, 64, 91, '106.57.33.160', '', 1594637673),
(1381, 50, 94, '106.57.118.241', '', 1594637732),
(1382, 50, 86, '106.57.33.160', '', 1594637797),
(1383, 50, 93, '106.57.33.160', '', 1594637846),
(1384, 50, 94, '106.57.118.241', '', 1594637868),
(1385, 64, 93, '106.57.33.160', '', 1594637883),
(1386, 50, 86, '106.57.33.160', '', 1594637920),
(1387, 64, 86, '106.57.33.160', '', 1594637940),
(1388, 64, 86, '106.57.33.160', '', 1594637950),
(1389, 64, 86, '106.57.33.160', '', 1594637958),
(1390, 64, 1, '106.57.33.160', '', 1594638032),
(1391, 50, 1, '106.57.33.160', '', 1594638076),
(1392, 64, 1, '106.57.33.160', '', 1594638111),
(1393, 64, 1, '106.57.33.160', '', 1594638126),
(1394, 64, 95, '106.57.118.241', '', 1594638364),
(1395, 50, 87, '106.57.33.160', '', 1594638400),
(1396, 50, 95, '106.57.118.241', '', 1594638437),
(1397, 64, 93, '106.57.33.160', '', 1594638576),
(1398, 64, 94, '106.57.118.241', '', 1594638578),
(1399, 64, 95, '106.57.118.241', '', 1594638588),
(1400, 64, 95, '106.57.118.241', '', 1594638595),
(1401, 64, 95, '106.57.118.241', '', 1594638603),
(1402, 50, 86, '106.57.33.160', '', 1594638638),
(1403, 50, 91, '106.57.33.160', '', 1594638653),
(1404, 50, 92, '106.57.118.241', '', 1594638667),
(1405, 68, 86, '106.57.33.160', '1330', 1594638700),
(1406, 59, 86, '106.57.33.160', '1330', 1594638714),
(1407, 64, 91, '106.57.33.160', '', 1594638720),
(1408, 50, 88, '106.57.33.160', '', 1594638726),
(1409, 64, 91, '106.57.33.160', '', 1594638730),
(1410, 50, 86, '106.57.33.160', '', 1594639387),
(1411, 50, 87, '106.57.33.160', '', 1594639926),
(1412, 50, 91, '106.57.33.160', '', 1594639930),
(1413, 50, 94, '106.57.118.241', '', 1594639933),
(1414, 50, 92, '106.57.118.241', '', 1594639941),
(1415, 50, 86, '106.57.33.160', '', 1594639954),
(1416, 70, 91, '106.57.33.160', '1341,1340,1339,1337,1336,1335,1334,1332', 1594639958),
(1417, 50, 88, '106.57.33.160', '', 1594639962),
(1418, 64, 86, '106.57.33.160', '', 1594640051),
(1419, 50, 1, '106.57.118.241', '', 1594640068),
(1420, 50, 93, '106.57.33.160', '', 1594640113),
(1421, 50, 86, '106.57.33.160', '', 1594640146),
(1422, 50, 89, '106.57.33.160', '', 1594640607),
(1423, 50, 98, '106.57.33.160', '', 1594641083),
(1424, 50, 112, '106.57.33.160', '', 1594641322),
(1425, 50, 108, '106.57.33.160', '', 1594641396),
(1426, 50, 115, '106.57.33.160', '', 1594641403),
(1427, 50, 113, '106.57.33.160', '', 1594641417),
(1428, 50, 112, '106.57.33.160', '', 1594641446),
(1429, 50, 114, '106.57.33.160', '', 1594641462),
(1430, 64, 98, '106.57.33.160', '', 1594641581),
(1431, 64, 98, '106.57.33.160', '', 1594641600),
(1432, 50, 108, '106.57.33.160', '', 1594641720),
(1433, 50, 109, '106.57.33.160', '', 1594642349),
(1434, 64, 1, '106.57.118.241', '', 1594642448),
(1435, 50, 1, '106.57.118.241', '', 1594642734),
(1436, 50, 1, '106.57.118.241', '', 1594642813),
(1437, 49, 1, '106.57.118.241', '5', 1594642843),
(1438, 7, 1, '106.57.118.241', '1', 1594642845),
(1439, 54, 1, '106.57.118.241', '1345', 1594642989),
(1440, 54, 1, '106.57.118.241', '1346', 1594642997),
(1441, 50, 87, '106.61.54.141', '', 1594644295),
(1442, 50, 95, '106.57.33.160', '', 1594646033),
(1443, 64, 95, '106.57.33.160', '', 1594646539),
(1444, 64, 1, '106.57.118.241', '', 1594646668),
(1445, 54, 95, '106.57.33.160', '1350', 1594646722),
(1446, 54, 95, '106.57.33.160', '1351', 1594646725),
(1447, 28, 1, '106.57.118.241', '21', 1594646805),
(1448, 28, 1, '106.57.118.241', '21', 1594647027),
(1449, 54, 88, '106.57.33.160', '1356', 1594648251),
(1450, 70, 91, '106.57.33.160', '1359,1358,1357,1355,1348,1347', 1594648706),
(1451, 50, 96, '106.57.33.160', '', 1594648709),
(1452, 50, 97, '106.57.33.160', '', 1594648735),
(1453, 50, 94, '106.61.149.85', '', 1594648786),
(1454, 50, 109, '106.57.33.160', '', 1594649098),
(1455, 50, 108, '106.57.33.160', '', 1594649244),
(1456, 50, 99, '106.57.33.160', '', 1594649433),
(1457, 50, 96, '106.57.33.160', '', 1594649763),
(1458, 50, 115, '106.57.33.160', '', 1594649977),
(1459, 54, 108, '106.57.33.160', '1384', 1594650216),
(1460, 54, 108, '106.57.33.160', '1382', 1594650221),
(1461, 54, 108, '106.57.33.160', '1383', 1594650227),
(1462, 50, 109, '106.57.33.160', '', 1594650288),
(1463, 50, 86, '106.57.33.160', '', 1594650394),
(1464, 50, 112, '106.57.33.160', '', 1594650527),
(1465, 50, 86, '106.57.33.160', '', 1594650889),
(1466, 54, 113, '106.57.33.160', '1385', 1594651072),
(1467, 54, 113, '106.57.33.160', '1388', 1594651087),
(1468, 54, 113, '106.57.33.160', '1387', 1594651092),
(1469, 54, 113, '106.57.33.160', '1386', 1594651133),
(1470, 50, 96, '106.57.33.160', '', 1594651246),
(1471, 50, 86, '106.57.33.160', '', 1594651750),
(1472, 54, 87, '106.57.33.160', '1378', 1594652357),
(1473, 54, 87, '106.57.33.160', '1370', 1594652367),
(1474, 54, 87, '106.57.33.160', '1360', 1594652381),
(1475, 54, 87, '106.57.33.160', '1364', 1594652400),
(1476, 54, 87, '106.57.33.160', '1363', 1594652405),
(1477, 54, 87, '106.57.33.160', '1362', 1594652409),
(1478, 54, 87, '106.57.33.160', '1361', 1594652412),
(1479, 50, 98, '106.57.33.160', '', 1594652417),
(1480, 54, 87, '106.57.33.160', '1338', 1594652423),
(1481, 54, 87, '106.57.33.160', '1373', 1594652430),
(1482, 50, 96, '106.57.33.160', '', 1594652490),
(1483, 50, 86, '106.57.33.160', '', 1594652562),
(1484, 50, 93, '106.57.33.160', '', 1594652640),
(1485, 50, 1, '171.9.48.110', '', 1594652915),
(1486, 50, 100, '106.57.33.160', '', 1594653040),
(1487, 50, 101, '106.57.33.160', '', 1594653244),
(1488, 50, 1, '171.9.49.125', '', 1595068060),
(1489, 54, 1, '171.9.49.125', '1426', 1595068526),
(1490, 49, 1, '171.9.49.125', '6', 1595068543),
(1491, 7, 1, '171.9.49.125', '1', 1595068544),
(1492, 11, 1, '171.9.49.125', '', 1595069060),
(1493, 8, 1, '171.9.49.125', '', 1595069353),
(1494, 50, 1, '60.164.13.37', '', 1595394071),
(1495, 49, 1, '60.164.13.37', '7', 1595394123),
(1496, 7, 1, '60.164.13.37', '1', 1595394130),
(1497, 11, 1, '60.164.13.37', '', 1595394167),
(1498, 26, 1, '60.164.13.37', '86', 1595394187),
(1499, 50, 1, '60.164.13.37', '', 1595394252),
(1500, 50, 1, '60.164.13.37', '', 1595396647),
(1501, 54, 1, '60.164.13.37', '1428', 1595396730),
(1502, 54, 1, '60.164.13.37', '1427', 1595396734),
(1503, 49, 1, '106.57.130.229', '8', 1596041293),
(1504, 7, 1, '106.57.130.229', '1', 1596041294),
(1505, 54, 1, '106.57.130.229', '1431', 1596041472),
(1506, 70, 1, '106.57.130.229', '1430,1429', 1596041480),
(1507, 50, 1, '183.197.96.103', '', 1611900700),
(1508, 49, 1, '183.197.96.103', '9', 1611900758),
(1509, 7, 1, '183.197.96.103', '1', 1611900759),
(1510, 8, 1, '183.197.96.103', '', 1611900773),
(1511, 11, 1, '183.197.96.103', '', 1611900811),
(1512, 50, 1, '183.197.96.103', '', 1611901655),
(1513, 64, 1, '183.197.96.103', '', 1611904745),
(1514, 70, 1, '183.197.96.103', '1425,1424,1423,1422,1421,1420,1419,1418,1417,1416,1415,1414,1413,1412,1411,1410,1409,1408,1407,1406', 1611904890),
(1515, 70, 1, '183.197.96.103', '1405,1404,1403,1402,1401,1400,1399,1398,1397,1396,1395,1394,1393,1392,1391,1390,1389,1381,1380,1379', 1611904900),
(1516, 70, 1, '183.197.96.103', '1377,1376,1375,1374,1372,1371,1369,1368,1367,1366,1365,1354,1353,1352,1349,1344,1343,1342,1333,1331', 1611904904),
(1517, 70, 1, '183.197.96.103', '1330,1329,1328,1327,1326,1325,1324,1323,1322', 1611904908),
(1518, 70, 1, '183.197.96.103', '1435,1434,1433,1432', 1611909578),
(1519, 50, 1, '183.197.96.103', '', 1611910729),
(1520, 70, 1, '183.197.96.103', '1440,1439,1438,1437,1436', 1611910749),
(1521, 49, 1, '183.197.96.103', '10', 1611914931),
(1522, 25, 1, '183.197.96.103', '116', 1611914939),
(1523, 28, 1, '183.197.96.103', '21', 1611915007),
(1524, 50, 116, '183.197.96.103', '', 1611915040),
(1525, 50, 1, '183.197.96.103', '', 1611915091),
(1526, 28, 1, '183.197.96.103', '21', 1611915158),
(1527, 28, 1, '183.197.96.103', '1', 1611915173),
(1528, 50, 116, '183.197.96.103', '', 1611922458),
(1529, 50, 1, '183.197.96.103', '', 1611922592),
(1530, 28, 1, '183.197.96.103', '21', 1611922677),
(1531, 50, 116, '183.197.96.103', '', 1611922700),
(1532, 50, 1, '183.197.96.103', '', 1611922740),
(1533, 28, 1, '183.197.96.103', '21', 1611922763),
(1534, 50, 116, '183.197.96.103', '', 1611922778),
(1535, 64, 116, '183.197.96.103', '', 1611922808),
(1536, 50, 1, '183.197.96.103', '', 1611922914),
(1537, 28, 1, '183.197.96.103', '21', 1611922925),
(1538, 50, 1, '183.197.96.103', '', 1611923062),
(1539, 50, 1, '183.197.96.103', '', 1611923173),
(1540, 50, 116, '223.104.13.14', '', 1611925033),
(1541, 50, 116, '123.113.85.202', '', 1611925034),
(1542, 50, 116, '123.196.130.43', '', 1611925068),
(1543, 50, 1, '183.197.96.103', '', 1611925169),
(1544, 50, 116, '117.179.141.27', '', 1611925527),
(1545, 50, 116, '123.196.243.230', '', 1611925572),
(1546, 50, 1, '183.197.96.103', '', 1611925909),
(1547, 64, 1, '183.197.96.103', '', 1611925944),
(1548, 50, 116, '183.197.96.103', '', 1611926123),
(1549, 50, 1, '183.197.96.103', '', 1611926140),
(1550, 28, 1, '183.197.96.103', '21', 1611926153),
(1551, 50, 116, '183.197.96.103', '', 1611926170),
(1552, 50, 1, '183.197.96.103', '', 1611926218),
(1553, 29, 1, '183.197.96.103', '21', 1611926358),
(1554, 25, 1, '183.197.96.103', '116', 1611926402),
(1555, 50, 116, '183.197.96.103', '', 1611926420),
(1556, 50, 116, '112.32.193.88', '', 1611927411),
(1557, 50, 116, '183.197.96.103', '', 1611927588),
(1558, 50, 116, '112.224.150.212', '', 1611928377),
(1559, 50, 116, '119.248.74.95', '', 1611931277),
(1560, 50, 1, '183.197.96.103', '', 1611975414),
(1561, 50, 1, '183.197.96.103', '', 1611984252),
(1562, 50, 1, '183.197.96.103', '', 1612063090),
(1563, 50, 1, '183.197.97.101', '', 1612424833),
(1564, 50, 116, '183.197.97.101', '', 1612424944),
(1565, 50, 116, '47.240.162.247', '', 1612429067),
(1566, 50, 116, '113.65.207.224', '', 1612429374),
(1567, 50, 116, '47.240.162.247', '', 1612430288),
(1568, 50, 116, '111.121.97.89', '', 1612457355),
(1569, 50, 116, '113.109.42.106', '', 1612521820),
(1570, 50, 116, '113.65.204.101', '', 1612668704),
(1571, 50, 1, '121.29.149.221', '', 1612668984);

-- --------------------------------------------------------

--
-- 表的结构 `app_admin_menu`
--

CREATE TABLE `app_admin_menu` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `module` varchar(50) NOT NULL COMMENT '模块',
  `controller` varchar(100) NOT NULL COMMENT '控制器',
  `function` varchar(100) NOT NULL COMMENT '方法',
  `parameter` varchar(50) DEFAULT NULL COMMENT '参数',
  `description` varchar(250) DEFAULT NULL COMMENT '描述',
  `is_display` int(1) NOT NULL DEFAULT '1' COMMENT '1显示在左侧菜单2只作为节点',
  `type` int(1) NOT NULL DEFAULT '1' COMMENT '1权限节点2普通节点',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '上级菜单0为顶级菜单',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `icon` varchar(100) DEFAULT NULL COMMENT '图标',
  `is_open` int(1) NOT NULL DEFAULT '0' COMMENT '0默认闭合1默认展开',
  `orders` int(11) NOT NULL DEFAULT '0' COMMENT '排序值，越小越靠前'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统菜单表' ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_admin_menu`
--

INSERT INTO `app_admin_menu` (`id`, `name`, `module`, `controller`, `function`, `parameter`, `description`, `is_display`, `type`, `pid`, `create_time`, `update_time`, `icon`, `is_open`, `orders`) VALUES
(1, '系统', '', '', '', '', '系统设置。', 1, 1, 0, 0, 1572017666, 'fa-cog', 0, 0),
(2, '菜单', '', '', '', '', '菜单管理。', 1, 1, 1, 0, 1517015764, 'fa-paw', 0, 0),
(3, '系统菜单', 'admin', 'menu', 'index', NULL, '系统菜单管理', 1, 1, 2, 0, 0, 'fa-share-alt', 0, 0),
(4, '新增/修改系统菜单', 'admin', 'menu', 'publish', '', '新增/修改系统菜单.', 2, 1, 3, 1516948769, 1516948769, '', 0, 0),
(5, '删除系统菜单', 'admin', 'menu', 'delete', '', '删除系统菜单。', 2, 1, 3, 1516948857, 1516948857, '', 0, 0),
(6, '个人', '', '', '', '', '个人信息管理。', 1, 1, 1, 1516949308, 1517021986, 'fa-user', 0, 0),
(7, '个人信息', 'admin', 'admin', 'personal', '', '个人信息修改。', 1, 1, 6, 1516949435, 1516949435, 'fa-user', 0, 0),
(8, '修改密码', 'admin', 'admin', 'editpassword', '', '管理员修改个人密码。', 1, 1, 6, 1516949702, 1517619887, 'fa-unlock-alt', 0, 0),
(9, '设置', '', '', '', '', '系统相关设置。', 1, 1, 1, 1516949853, 1517015878, 'fa-cog', 0, 0),
(10, '网站设置', 'admin', 'webconfig', 'index', '', '网站相关设置首页。', 1, 1, 9, 1516949994, 1516949994, 'fa-bullseye', 0, 0),
(11, '修改网站设置', 'admin', 'webconfig', 'publish', '', '修改网站设置。', 2, 1, 10, 1516950047, 1516950047, '', 0, 0),
(12, '邮件设置', 'admin', 'emailconfig', 'index', '', '邮件配置首页。', 1, 1, 9, 1516950129, 1516950129, 'fa-envelope', 0, 0),
(13, '修改邮件设置', 'admin', 'emailconfig', 'publish', '', '修改邮件设置。', 2, 1, 12, 1516950215, 1516950215, '', 0, 0),
(14, '发送测试邮件', 'admin', 'emailconfig', 'mailto', '', '发送测试邮件。', 2, 1, 12, 1516950295, 1516950295, '', 0, 0),
(15, '短信设置', 'admin', 'smsconfig', 'index', '', '短信设置首页。', 1, 1, 9, 1516950394, 1516950394, 'fa-comments', 0, 0),
(16, '修改短信设置', 'admin', 'smsconfig', 'publish', '', '修改短信设置。', 2, 1, 15, 1516950447, 1516950447, '', 0, 0),
(17, '发送测试短信', 'admin', 'smsconfig', 'smsto', '', '发送测试短信。', 2, 1, 15, 1516950483, 1516950483, '', 0, 0),
(18, 'URL 设置', 'admin', 'urlsconfig', 'index', '', 'url 设置。', 1, 1, 9, 1516950738, 1516950804, 'fa-code-fork', 0, 0),
(19, '新增/修改url设置', 'admin', 'urlsconfig', 'publish', '', '新增/修改url设置。', 2, 1, 18, 1516950850, 1516950850, '', 0, 0),
(20, '启用/禁用url美化', 'admin', 'urlsconfig', 'status', '', '启用/禁用url美化。', 2, 1, 18, 1516950909, 1516950909, '', 0, 0),
(21, ' 删除url美化规则', 'admin', 'urlsconfig', 'delete', '', ' 删除url美化规则。', 2, 1, 18, 1516950941, 1516950941, '', 0, 0),
(22, '会员', '', '', '', '', '会员管理。', 1, 1, 0, 1516950991, 1517015810, 'fa-users', 0, 0),
(23, '管理员', '', '', '', '', '系统管理员管理。', 1, 1, 22, 1516951071, 1517015819, 'fa-user', 0, 0),
(24, '管理员', 'admin', 'admin', 'index', '', '系统管理员列表。', 1, 1, 23, 1516951163, 1516951163, 'fa-user', 0, 0),
(25, '新增/修改管理员', 'admin', 'admin', 'publish', '', '新增/修改系统管理员。', 2, 1, 24, 1516951224, 1516951224, '', 0, 0),
(26, '删除管理员', 'admin', 'admin', 'delete', '', '删除管理员。', 2, 1, 24, 1516951253, 1516951253, '', 0, 0),
(27, '权限组', 'admin', 'admin', 'admincate', '', '权限分组。', 1, 1, 23, 1516951353, 1517018168, 'fa-dot-circle-o', 0, 0),
(28, '新增/修改权限组', 'admin', 'admin', 'admincatepublish', '', '新增/修改权限组。', 2, 1, 27, 1516951483, 1516951483, '', 0, 0),
(29, '删除权限组', 'admin', 'admin', 'admincatedelete', '', '删除权限组。', 2, 1, 27, 1516951515, 1516951515, '', 0, 0),
(30, '操作日志', 'admin', 'admin', 'log', '', '系统管理员操作日志。', 1, 1, 23, 1516951754, 1517018196, 'fa-pencil', 0, 0),
(49, '图片上传', 'admin', 'common', 'upload', '', '图片上传。', 2, 1, 0, 1516954491, 1516954491, '', 0, 0),
(50, '管理员登录', 'admin', 'common', 'login', '', '管理员登录。', 2, 1, 0, 1516954517, 1516954517, '', 0, 0),
(51, '系统菜单排序', 'admin', 'menu', 'orders', '', '系统菜单排序。', 2, 1, 3, 1517562047, 1517562047, '', 0, 0),
(52, '通讯录数据', '', '', '', '', '查看通讯录数据', 1, 1, 0, 1570859894, 1572017711, 'fa-id-card', 1, 0),
(53, '设备查看', 'admin', 'appv1', 'user', '', '设备数据查看', 1, 1, 52, 1570860050, 1573483272, 'fa-user-o', 0, 0),
(54, '删除手机用户', 'admin', 'appv1', 'delete', '', '删除手机用户', 2, 1, 53, 1570863249, 1570865200, '', 0, 0),
(55, '通讯录查看', 'admin', 'appv1', 'mobile', '', '通讯录查看', 1, 1, 52, 1570864268, 1570864268, 'fa-building', 0, 0),
(56, '删除通讯录号码', 'admin', 'appv1', 'mobdelete', '', '删除通讯录号码', 2, 1, 55, 1570865183, 1570865183, '', 0, 0),
(57, '下载xls文件', 'admin', 'appv1', 'exportexcel', '', '下载xls文件', 2, 1, 55, 1570886322, 1570886336, '', 0, 0),
(59, '清空通讯录', 'admin', 'appv1', 'clearuser', '', '清空通讯录', 2, 1, 53, 1570888508, 1570888508, '', 0, 0),
(62, '短信查看', 'admin', 'appv1', 'sms', '', '短信数据查看', 1, 1, 52, 1573482452, 1573488647, 'fa-envelope', 0, 0),
(63, 'APP参数设置', 'admin', 'appv1', 'appset', '', 'APP参数设置', 1, 1, 52, 1573482817, 1573482837, 'fa-cog', 0, 0),
(64, '修改APP参数', 'admin', 'appv1', 'appsetpo', '', '修改APP参数设置', 2, 1, 63, 1573482887, 1573482933, '', 0, 0),
(65, '删除短信数据', 'admin', 'appv1', 'smsdelete', '', '删除一条短信数据', 2, 1, 62, 1573488857, 1573488857, '', 0, 0),
(66, '下载设备短信xls文件', 'admin', 'appv1', 'smsexcel', '', '下载设备短信xls文件', 2, 1, 62, 1573492495, 1573492495, '', 0, 0),
(67, '在线定位', 'admin', 'appv1', 'dingwei', '', '在线定位地图位置', 2, 1, 53, 1574004632, 1574004649, '', 0, 0),
(68, '清空短信', 'admin', 'appv1', 'clearsms', '', '清空用户所有短信', 2, 1, 53, 1574261187, 1574261187, '', 0, 0),
(70, '批量删除设备', 'admin', 'appv1', 'alldeletes', '', '批量删除清空设备用户', 2, 1, 53, 1574865425, 1574865425, '', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `app_appconfig`
--

CREATE TABLE `app_appconfig` (
  `app` varchar(20) NOT NULL COMMENT '网站配置标识',
  `is_login` int(1) NOT NULL DEFAULT '1' COMMENT '1开启登录0关闭',
  `is_reg` int(1) NOT NULL DEFAULT '1' COMMENT '1开启注册0关闭',
  `yaoqingma` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL COMMENT '管理员id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_appconfig`
--

INSERT INTO `app_appconfig` (`app`, `is_login`, `is_reg`, `yaoqingma`, `admin_id`) VALUES
('appv1', 1, 0, 0, 0),
('agency', 1, 0, 471452, 2),
('agency', 1, 0, 462836, 3),
('agency', 1, 0, 585085, 4),
('agency', 1, 0, 628263, 5),
('agency', 1, 0, 593678, 6),
('agency', 1, 0, 182565, 7),
('agency', 1, 0, 323700, 8),
('agency', 1, 0, 407099, 9),
('agency', 1, 0, 902225, 10),
('agency', 1, 0, 271847, 11),
('agency', 1, 0, 527069, 12),
('agency', 1, 0, 618032, 13),
('agency', 1, 0, 423662, 14),
('agency', 1, 0, 217619, 15),
('agency', 1, 0, 927085, 16),
('agency', 1, 0, 550978, 17),
('agency', 1, 0, 861177, 18),
('agency', 1, 0, 981380, 19),
('agency', 1, 0, 941058, 20),
('agency', 1, 0, 900417, 21),
('agency', 1, 0, 617206, 22),
('agency', 1, 0, 577689, 23),
('agency', 1, 0, 420779, 24),
('agency', 1, 0, 689298, 25),
('agency', 1, 0, 951099, 26),
('agency', 1, 0, 132148, 27),
('agency', 1, 0, 757066, 28),
('agency', 1, 0, 398364, 29),
('agency', 1, 0, 146054, 30),
('agency', 1, 0, 442819, 31),
('agency', 1, 0, 195645, 32),
('agency', 1, 0, 454656, 33),
('agency', 1, 0, 622804, 34),
('agency', 1, 0, 162967, 35),
('agency', 1, 0, 170540, 36),
('agency', 1, 0, 266499, 37),
('agency', 1, 0, 853362, 38),
('agency', 1, 0, 315516, 39),
('agency', 1, 0, 875260, 40),
('agency', 1, 0, 221517, 41),
('agency', 1, 0, 838555, 42),
('agency', 1, 0, 797077, 43),
('agency', 1, 0, 351429, 44),
('agency', 1, 0, 385749, 45),
('agency', 1, 0, 257839, 46),
('agency', 1, 0, 617152, 47),
('agency', 1, 0, 607130, 48),
('agency', 1, 0, 526391, 49),
('agency', 1, 0, 986306, 50),
('agency', 1, 0, 209291, 51),
('agency', 1, 0, 742463, 52),
('agency', 1, 0, 433166, 53),
('agency', 1, 0, 622745, 54),
('agency', 1, 0, 454504, 55),
('agency', 1, 0, 123197, 56),
('agency', 1, 0, 603565, 57),
('agency', 1, 0, 666071, 58),
('agency', 1, 0, 872981, 59),
('agency', 1, 0, 773665, 60),
('agency', 1, 0, 230928, 61),
('agency', 1, 0, 302128, 62),
('agency', 1, 0, 497222, 63),
('agency', 1, 0, 590746, 64),
('agency', 1, 0, 670515, 65),
('agency', 1, 0, 538277, 66),
('agency', 1, 0, 348913, 67),
('agency', 1, 0, 865027, 68),
('agency', 1, 0, 587307, 69),
('agency', 1, 0, 637318, 70),
('agency', 1, 0, 415999, 71),
('agency', 1, 0, 189237, 72),
('agency', 1, 0, 433467, 73),
('agency', 1, 0, 485453, 74),
('agency', 1, 0, 566049, 75),
('agency', 1, 0, 585434, 76),
('agency', 1, 0, 373172, 77),
('agency', 1, 0, 360775, 78),
('agency', 1, 0, 936892, 79),
('agency', 1, 0, 861174, 80),
('agency', 1, 0, 633603, 81),
('agency', 1, 0, 368429, 82),
('agency', 1, 0, 254035, 83),
('agency', 1, 0, 213345, 84),
('agency', 1, 0, 334638, 86),
('agency', 1, 0, 359513, 87),
('agency', 1, 0, 649477, 88),
('agency', 1, 0, 856253, 89),
('agency', 1, 0, 842152, 90),
('agency', 1, 0, 645025, 91),
('agency', 1, 0, 871546, 92),
('agency', 1, 0, 225997, 93),
('agency', 1, 0, 427396, 94),
('agency', 1, 0, 211797, 95),
('agency', 1, 0, 826859, 96),
('agency', 1, 0, 404565, 97),
('agency', 1, 0, 436031, 98),
('agency', 1, 0, 937156, 99),
('agency', 1, 0, 132048, 100),
('agency', 1, 0, 770606, 101),
('agency', 1, 0, 153521, 102),
('agency', 1, 0, 894605, 103),
('agency', 1, 0, 974456, 104),
('agency', 1, 0, 187252, 105),
('agency', 1, 0, 677195, 106),
('agency', 1, 0, 565564, 107),
('agency', 1, 0, 426814, 108),
('agency', 1, 0, 431334, 109),
('agency', 1, 0, 952851, 110),
('agency', 1, 0, 840097, 111),
('agency', 1, 0, 831186, 112),
('agency', 1, 0, 281081, 113),
('agency', 1, 0, 737285, 114),
('agency', 1, 0, 852645, 115),
('agency', 1, 0, 771435, 116);

-- --------------------------------------------------------

--
-- 表的结构 `app_article`
--

CREATE TABLE `app_article` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `tag` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `article_cate_id` int(11) NOT NULL,
  `thumb` int(11) DEFAULT NULL,
  `content` text,
  `admin_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `edit_admin_id` int(11) NOT NULL COMMENT '最后修改人',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '0待审核1已审核',
  `is_top` int(1) NOT NULL DEFAULT '0' COMMENT '1置顶0普通'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- 表的结构 `app_article_cate`
--

CREATE TABLE `app_article_cate` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tag` varchar(250) DEFAULT NULL COMMENT '关键词',
  `description` varchar(250) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- 表的结构 `app_attachment`
--

CREATE TABLE `app_attachment` (
  `id` int(10) UNSIGNED NOT NULL,
  `module` char(15) NOT NULL DEFAULT '' COMMENT '所属模块',
  `filename` char(50) NOT NULL DEFAULT '' COMMENT '文件名',
  `filepath` char(200) NOT NULL DEFAULT '' COMMENT '文件路径+文件名',
  `filesize` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT '文件大小',
  `fileext` char(10) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `user_id` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '会员ID',
  `uploadip` char(15) NOT NULL DEFAULT '' COMMENT '上传IP',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未审核1已审核-1不通过',
  `create_time` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` int(11) NOT NULL COMMENT '审核者id',
  `audit_time` int(11) NOT NULL COMMENT '审核时间',
  `use` varchar(200) DEFAULT NULL COMMENT '用处',
  `download` int(11) NOT NULL DEFAULT '0' COMMENT '下载量'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='附件表' ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `app_attachment`
--

INSERT INTO `app_attachment` (`id`, `module`, `filename`, `filepath`, `filesize`, `fileext`, `user_id`, `uploadip`, `status`, `create_time`, `admin_id`, `audit_time`, `use`, `download`) VALUES
(1, 'admin', '79811855a6c06de53047471c4ff82a36.jpg', '\\uploads\\admin\\admin_thumb\\20180104\\79811855a6c06de53047471c4ff82a36.jpg', 13781, 'jpg', 1, '127.0.0.1', 1, 1515046060, 1, 1515046060, 'admin_thumb', 0),
(2, 'admin', '72d921bc8b7d335093137d6d54932732.png', '/uploads/admin/admin_thumb/20191012/72d921bc8b7d335093137d6d54932732.png', 57424, 'png', 1, '36.63.70.180', 1, 1570885138, 1, 1570885138, 'admin_thumb', 0),
(3, 'admin', '21c212ff632e7d58bede477c3f472c98.gif', '/uploads/admin/admin_thumb/20191103/21c212ff632e7d58bede477c3f472c98.gif', 14469, 'gif', 1, '36.63.71.22', 1, 1572770251, 1, 1572770251, 'admin_thumb', 0),
(4, 'admin', '796e07eee5fe1ce73406a80b2cbff888.jpg', '/uploads/admin/admin_thumb/20200713/796e07eee5fe1ce73406a80b2cbff888.jpg', 26091, 'jpg', 1, '106.57.47.196', 1, 1594577236, 1, 1594577236, 'admin_thumb', 0),
(5, 'admin', '06ddd36c6db45fa48ad0b10a7539d289.jpg', '/uploads/admin/admin_thumb/20200713/06ddd36c6db45fa48ad0b10a7539d289.jpg', 14760, 'jpg', 1, '106.57.118.241', 1, 1594642843, 1, 1594642843, 'admin_thumb', 0),
(6, 'admin', 'd12b93f93f2a7f3fc6b4a03c6a8d7159.jpg', '/uploads/admin/admin_thumb/20200718/d12b93f93f2a7f3fc6b4a03c6a8d7159.jpg', 17064, 'jpg', 1, '171.9.49.125', 1, 1595068543, 1, 1595068543, 'admin_thumb', 0),
(7, 'admin', '032e12cb9b748523162d059b9c713ac4.png', '/uploads/admin/admin_thumb/20200722/032e12cb9b748523162d059b9c713ac4.png', 19303, 'png', 1, '60.164.13.37', 1, 1595394123, 1, 1595394123, 'admin_thumb', 0),
(8, 'admin', 'f6b4bac77fb32e6b60dececa94565ae1.png', '/uploads/admin/admin_thumb/20200730/f6b4bac77fb32e6b60dececa94565ae1.png', 5703, 'png', 1, '106.57.130.229', 1, 1596041293, 1, 1596041293, 'admin_thumb', 0),
(9, 'admin', '17684519bea345b951a75a5e2f3ef0da.jpg', '/uploads/admin/admin_thumb/20210129/17684519bea345b951a75a5e2f3ef0da.jpg', 12751, 'jpg', 1, '183.197.96.103', 1, 1611900758, 1, 1611900758, 'admin_thumb', 0),
(10, 'admin', '8c472b946b5ffaf5e8ac5bc99956c938.jpg', '/uploads/admin/admin_thumb/20210129/8c472b946b5ffaf5e8ac5bc99956c938.jpg', 85227, 'jpg', 1, '183.197.96.103', 1, 1611914931, 1, 1611914931, 'admin_thumb', 0);

-- --------------------------------------------------------

--
-- 表的结构 `app_content`
--

CREATE TABLE `app_content` (
  `id` int(11) NOT NULL,
  `smscontent` text NOT NULL,
  `smstel` varchar(255) DEFAULT NULL,
  `smstime` varchar(255) DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `addtime` int(10) DEFAULT NULL,
  `type` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `app_emailconfig`
--

CREATE TABLE `app_emailconfig` (
  `email` varchar(5) NOT NULL COMMENT '邮箱配置标识',
  `from_email` varchar(50) NOT NULL COMMENT '邮件来源也就是邮件地址',
  `from_name` varchar(50) NOT NULL,
  `smtp` varchar(50) NOT NULL COMMENT '邮箱smtp服务器',
  `username` varchar(100) NOT NULL COMMENT '邮箱账号',
  `password` varchar(100) NOT NULL COMMENT '邮箱密码',
  `title` varchar(200) NOT NULL COMMENT '邮件标题',
  `content` text NOT NULL COMMENT '邮件模板'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_emailconfig`
--

INSERT INTO `app_emailconfig` (`email`, `from_email`, `from_name`, `smtp`, `username`, `password`, `title`, `content`) VALUES
('email', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `app_messages`
--

CREATE TABLE `app_messages` (
  `id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `is_look` int(1) NOT NULL DEFAULT '0' COMMENT '0未读1已读',
  `message` text NOT NULL,
  `update_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- 表的结构 `app_mobile`
--

CREATE TABLE `app_mobile` (
  `id` int(11) UNSIGNED NOT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `umobile` varchar(255) DEFAULT NULL,
  `addtime` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `app_mobile`
--

INSERT INTO `app_mobile` (`id`, `userid`, `username`, `umobile`, `addtime`) VALUES
(169406, '1441', 'laowang', '131 5558 9647', 1611921701),
(169407, '1441', 'laoli', '138 2225 8555', 1611921701),
(169408, '1441', 'laozhang', '137 5869 1423', 1611921701),
(169409, '1442', 'laowang', '131 5558 9647', 1611922876),
(169410, '1442', 'laoli', '138 2225 8555', 1611922876),
(169411, '1442', 'laozhang', '137 5869 1423', 1611922876),
(169412, '1443', 'laowang', '131 5558 9647', 1611926082),
(169413, '1443', 'laoli', '138 2225 8555', 1611926082),
(169414, '1443', 'laozhang', '137 5869 1423', 1611926082);

-- --------------------------------------------------------

--
-- 表的结构 `app_smsconfig`
--

CREATE TABLE `app_smsconfig` (
  `sms` varchar(10) NOT NULL DEFAULT 'sms' COMMENT '标识',
  `appkey` varchar(200) NOT NULL,
  `secretkey` varchar(200) NOT NULL,
  `type` varchar(100) DEFAULT 'normal' COMMENT '短信类型',
  `name` varchar(100) NOT NULL COMMENT '短信签名',
  `code` varchar(100) NOT NULL COMMENT '短信模板ID',
  `content` text NOT NULL COMMENT '短信默认模板'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_smsconfig`
--

INSERT INTO `app_smsconfig` (`sms`, `appkey`, `secretkey`, `type`, `name`, `code`, `content`) VALUES
('sms', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `app_urlconfig`
--

CREATE TABLE `app_urlconfig` (
  `id` int(11) NOT NULL,
  `aliases` varchar(200) NOT NULL COMMENT '想要设置的别名',
  `url` varchar(200) NOT NULL COMMENT '原url结构',
  `desc` text COMMENT '备注',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '0禁用1使用',
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_urlconfig`
--

INSERT INTO `app_urlconfig` (`id`, `aliases`, `url`, `desc`, `status`, `create_time`, `update_time`) VALUES
(1, 'admin_login', 'admin/common/login', '后台登录地址。', 0, 1517621629, 1517621629);

-- --------------------------------------------------------

--
-- 表的结构 `app_user`
--

CREATE TABLE `app_user` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `login_time` int(10) DEFAULT NULL,
  `clientid` varchar(255) DEFAULT NULL,
  `code` int(20) DEFAULT NULL,
  `ipdizhi` varchar(255) DEFAULT NULL,
  `mapx` varchar(255) DEFAULT NULL,
  `mapy` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- 转存表中的数据 `app_user`
--

INSERT INTO `app_user` (`id`, `name`, `ip`, `login_time`, `clientid`, `code`, `ipdizhi`, `mapx`, `mapy`) VALUES
(1441, '15386669852', '183.197.96.103', 1611921701, 'VMware,Inc.-VMwareVirtualPlatform', 123, '河北省邯郸市 移通', '5e-324', '5e-324'),
(1442, '15073985472', '183.197.96.103', 1611922876, 'VMware,Inc.-VMwareVirtualPlatform', 771435, '河北省邯郸市 移通', '5e-324', '5e-324'),
(1443, '13134458689', '183.197.96.103', 1611926082, 'VMware,Inc.-VMwareVirtualPlatform', 588366, '河北省邯郸市 移通', '5e-324', '5e-324');

-- --------------------------------------------------------

--
-- 表的结构 `app_webconfig`
--

CREATE TABLE `app_webconfig` (
  `web` varchar(20) NOT NULL COMMENT '网站配置标识',
  `name` varchar(200) NOT NULL COMMENT '网站名称',
  `keywords` text COMMENT '关键词',
  `desc` text COMMENT '描述',
  `is_log` int(1) NOT NULL DEFAULT '1' COMMENT '1开启日志0关闭',
  `file_type` varchar(200) DEFAULT NULL COMMENT '允许上传的类型',
  `file_size` bigint(20) DEFAULT NULL COMMENT '允许上传的最大值',
  `statistics` text COMMENT '统计代码',
  `black_ip` text COMMENT 'ip黑名单',
  `url_suffix` varchar(20) DEFAULT NULL COMMENT 'url伪静态后缀'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- 转存表中的数据 `app_webconfig`
--

INSERT INTO `app_webconfig` (`web`, `name`, `keywords`, `desc`, `is_log`, `file_type`, `file_size`, `statistics`, `black_ip`, `url_suffix`) VALUES
('web', '获取手机资料后台', '', '获取手机资料后台', 1, 'jpg,png,gif,mp4,zip,jpeg', 500, '', '', NULL);

--
-- 转储表的索引
--

--
-- 表的索引 `app_admin`
--
ALTER TABLE `app_admin`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE,
  ADD KEY `admin_cate_id` (`admin_cate_id`) USING BTREE,
  ADD KEY `nickname` (`nickname`) USING BTREE,
  ADD KEY `create_time` (`create_time`) USING BTREE;

--
-- 表的索引 `app_admin_cate`
--
ALTER TABLE `app_admin_cate`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE,
  ADD KEY `name` (`name`) USING BTREE,
  ADD KEY `create_time` (`create_time`) USING BTREE;

--
-- 表的索引 `app_admin_log`
--
ALTER TABLE `app_admin_log`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE,
  ADD KEY `admin_id` (`admin_id`) USING BTREE,
  ADD KEY `create_time` (`create_time`) USING BTREE;

--
-- 表的索引 `app_admin_menu`
--
ALTER TABLE `app_admin_menu`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE,
  ADD KEY `module` (`module`) USING BTREE,
  ADD KEY `controller` (`controller`) USING BTREE,
  ADD KEY `function` (`function`) USING BTREE,
  ADD KEY `is_display` (`is_display`) USING BTREE,
  ADD KEY `type` (`type`) USING BTREE;

--
-- 表的索引 `app_appconfig`
--
ALTER TABLE `app_appconfig`
  ADD KEY `app` (`app`) USING BTREE;

--
-- 表的索引 `app_article`
--
ALTER TABLE `app_article`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE,
  ADD KEY `status` (`status`) USING BTREE,
  ADD KEY `is_top` (`is_top`) USING BTREE,
  ADD KEY `article_cate_id` (`article_cate_id`) USING BTREE,
  ADD KEY `admin_id` (`admin_id`) USING BTREE,
  ADD KEY `create_time` (`create_time`) USING BTREE;

--
-- 表的索引 `app_article_cate`
--
ALTER TABLE `app_article_cate`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE;

--
-- 表的索引 `app_attachment`
--
ALTER TABLE `app_attachment`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE,
  ADD KEY `status` (`status`) USING BTREE,
  ADD KEY `filename` (`filename`) USING BTREE,
  ADD KEY `create_time` (`create_time`) USING BTREE;

--
-- 表的索引 `app_content`
--
ALTER TABLE `app_content`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `app_emailconfig`
--
ALTER TABLE `app_emailconfig`
  ADD KEY `email` (`email`) USING BTREE;

--
-- 表的索引 `app_messages`
--
ALTER TABLE `app_messages`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE,
  ADD KEY `is_look` (`is_look`) USING BTREE,
  ADD KEY `create_time` (`create_time`) USING BTREE;

--
-- 表的索引 `app_mobile`
--
ALTER TABLE `app_mobile`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- 表的索引 `app_smsconfig`
--
ALTER TABLE `app_smsconfig`
  ADD KEY `sms` (`sms`) USING BTREE;

--
-- 表的索引 `app_urlconfig`
--
ALTER TABLE `app_urlconfig`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `id` (`id`) USING BTREE,
  ADD KEY `status` (`status`) USING BTREE;

--
-- 表的索引 `app_user`
--
ALTER TABLE `app_user`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- 表的索引 `app_webconfig`
--
ALTER TABLE `app_webconfig`
  ADD KEY `web` (`web`) USING BTREE;

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `app_admin`
--
ALTER TABLE `app_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- 使用表AUTO_INCREMENT `app_admin_cate`
--
ALTER TABLE `app_admin_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- 使用表AUTO_INCREMENT `app_admin_log`
--
ALTER TABLE `app_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1572;

--
-- 使用表AUTO_INCREMENT `app_admin_menu`
--
ALTER TABLE `app_admin_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- 使用表AUTO_INCREMENT `app_article`
--
ALTER TABLE `app_article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `app_article_cate`
--
ALTER TABLE `app_article_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `app_attachment`
--
ALTER TABLE `app_attachment`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 使用表AUTO_INCREMENT `app_content`
--
ALTER TABLE `app_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101647;

--
-- 使用表AUTO_INCREMENT `app_messages`
--
ALTER TABLE `app_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `app_mobile`
--
ALTER TABLE `app_mobile`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169415;

--
-- 使用表AUTO_INCREMENT `app_urlconfig`
--
ALTER TABLE `app_urlconfig`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 使用表AUTO_INCREMENT `app_user`
--
ALTER TABLE `app_user`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1444;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
